# archivos.py
import csv

def guardar_csv(inventario, ruta):
    if not inventario:
        print("Inventario vacío, no se puede guardar")
        return

    try:
        with open(ruta, "w", newline="") as archivo:
            writer = csv.writer(archivo)
            writer.writerow(["nombre", "precio", "cantidad"])

            for p in inventario:
                writer.writerow([p["nombre"], p["precio"], p["cantidad"]])

        print(f"Inventario guardado en {ruta}")

    except Exception as e:
        print("Error al guardar:", e)


def cargar_csv(ruta):
    inventario = []
    errores = 0

    try:
        with open(ruta, "r") as archivo:
            reader = csv.reader(archivo)
            header = next(reader)

            if header != ["nombre", "precio", "cantidad"]:
                print("Formato inválido")
                return []

            for fila in reader:
                try:
                    nombre = fila[0]
                    precio = float(fila[1])
                    cantidad = int(fila[2])

                    if precio < 0 or cantidad < 0:
                        raise ValueError

                    inventario.append({
                        "nombre": nombre,
                        "precio": precio,
                        "cantidad": cantidad
                    })

                except:
                    errores += 1

        print(f"Archivo cargado. Filas inválidas: {errores}")
        return inventario

    except FileNotFoundError:
        print("Archivo no encontrado")
        return []
