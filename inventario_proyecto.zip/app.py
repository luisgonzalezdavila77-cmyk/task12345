# app.py

from servicios import *
from archivos import *

inventario = []

def menu():
    while True:
        print("\n===== MENÚ =====")
        print("1. Agregar")
        print("2. Mostrar")
        print("3. Buscar")
        print("4. Actualizar")
        print("5. Eliminar")
        print("6. Estadísticas")
        print("7. Guardar CSV")
        print("8. Cargar CSV")
        print("9. Salir")

        op = input("Opción: ")

        if op == "1":
            nombre = input("Nombre: ")
            precio = float(input("Precio: "))
            cantidad = int(input("Cantidad: "))
            agregar_producto(inventario, nombre, precio, cantidad)

        elif op == "2":
            mostrar_inventario(inventario)

        elif op == "3":
            nombre = input("Buscar: ")
            p = buscar_producto(inventario, nombre)
            print(p if p else "No encontrado")

        elif op == "4":
            nombre = input("Producto a actualizar: ")
            precio = float(input("Nuevo precio: "))
            cantidad = int(input("Nueva cantidad: "))
            if actualizar_producto(inventario, nombre, precio, cantidad):
                print("Actualizado")
            else:
                print("No encontrado")

        elif op == "5":
            nombre = input("Eliminar: ")
            if eliminar_producto(inventario, nombre):
                print("Eliminado")
            else:
                print("No encontrado")

        elif op == "6":
            stats = calcular_estadisticas(inventario)
            if stats:
                print(stats)
            else:
                print("Inventario vacío")

        elif op == "7":
            ruta = input("Ruta archivo: ")
            guardar_csv(inventario, ruta)

        elif op == "8":
            ruta = input("Ruta archivo: ")
            nuevos = cargar_csv(ruta)

            opcion = input("¿Sobrescribir inventario? (s/n): ")
            if opcion.lower() == "s":
                inventario.clear()
                inventario.extend(nuevos)
            else:
                inventario.extend(nuevos)

        elif op == "9":
            break

        else:
            print("Opción inválida")

menu()
